module.exports = {
	rootDir: './tests',
};